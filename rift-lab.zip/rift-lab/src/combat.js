import * as THREE from "three";
import { seededRandom, clamp } from "./kinematics.js";

const rng = seededRandom(93),
  up = new THREE.Vector3(0, 1, 0);
const metal = new THREE.MeshStandardMaterial({
  color: 0x39433a,
  roughness: 0.6,
  metalness: 0.7,
});
const shell = new THREE.MeshStandardMaterial({
  color: 0xaaa08a,
  roughness: 0.8,
  metalness: 0.5,
});
const red = new THREE.MeshStandardMaterial({
  color: 0xff6544,
  emissive: 0xff3c19,
  emissiveIntensity: 3,
});
const sphereGeo = new THREE.SphereGeometry(1, 10, 8),
  boxGeo = new THREE.BoxGeometry(1, 1, 1);
const missileBodyGeo = new THREE.CylinderGeometry(0.13, 0.13, 1.45, 10),
  missileNoseGeo = new THREE.ConeGeometry(0.13, 0.4, 10);

export class Combat {
  constructor(scene, onEvent, collision = null) {
    this.scene = scene;
    this.onEvent = onEvent;
    this.collision = collision;
    this.terrainHits = 0;
    this.enemies = [];
    this.bullets = [];
    this.effects = [];
    this.score = 0;
    this.enabled = true;
    this.shotCooldown = 0;
    this.empCooldown = 0;
    this.soundEnabled = false;
    this.weaponMode = "bullet";
    this.reset();
  }
  reset(center = new THREE.Vector3()) {
    this.center = center.clone();
    this.terrainHits = 0;
    this.missilesFired = 0;
    this.explosions = 0;
    for (const e of this.enemies) this.scene.remove(e.root);
    this.enemies = [];
    for (const b of this.bullets) {
      this.removeProjectile(b);
    }
    this.bullets = [];
    for (const e of this.effects) {
      this.scene.remove(e.mesh);
      e.mesh.geometry.dispose();
      e.mesh.material.dispose();
    }
    this.effects = [];
    this.score = 0;
    this.shotCooldown = 0;
    this.empCooldown = 0;
    for (let i = 0; i < 6; i++) this.spawn(i);
  }
  spawn(index) {
    const root = new THREE.Group();
    const angle = (index * Math.PI) / 3 + 0.5,
      r = 18 + rng() * 10;
    root.position.set(
      this.center.x + Math.sin(angle) * r,
      this.center.y + 3.6 + rng() * 2,
      this.center.z + Math.cos(angle) * r,
    );
    this.scene.add(root);
    root.visible = this.enabled;
    const body = new THREE.Mesh(sphereGeo, shell);
    body.scale.set(0.9, 0.52, 0.9);
    body.castShadow = true;
    root.add(body);
    const eye = new THREE.Mesh(sphereGeo, red);
    eye.position.set(0, -0.12, -0.82);
    eye.scale.set(0.14, 0.14, 0.08);
    root.add(eye);
    const rotors = [];
    for (const side of [-1, 1]) {
      const arm = new THREE.Mesh(boxGeo, metal);
      arm.scale.set(2.5, 0.12, 0.16);
      arm.position.set(0, 0, side * 0.5);
      root.add(arm);
      for (const x of [-1.35, 1.35]) {
        const rotor = new THREE.Mesh(
          new THREE.TorusGeometry(0.46, 0.08, 5, 16),
          metal,
        );
        rotor.rotation.x = Math.PI / 2;
        rotor.position.set(x, 0, side * 0.5);
        root.add(rotor);
        const blade = new THREE.Mesh(boxGeo, metal);
        blade.scale.set(0.85, 0.03, 0.09);
        blade.position.copy(rotor.position);
        root.add(blade);
        rotors.push(blade);
      }
    }
    const indicator = new THREE.Mesh(
      new THREE.RingGeometry(1.4, 1.44, 32),
      new THREE.MeshBasicMaterial({
        color: 0xe99956,
        transparent: true,
        opacity: 0.28,
        side: THREE.DoubleSide,
      }),
    );
    indicator.rotation.x = -Math.PI / 2;
    indicator.position.y = -root.position.y + 0.035;
    root.add(indicator);
    this.enemies.push({
      root,
      rotors,
      indicator,
      health: 3,
      angle,
      radius: r,
      baseHeight: root.position.y - this.center.y,
      shootTime: 2 + index * 0.7,
      respawn: 0,
      dead: false,
    });
  }
  setEnabled(enabled) {
    this.enabled = enabled;
    for (const e of this.enemies) e.root.visible = enabled && !e.dead;
  }
  sound(kind) {
    if (!this.soundEnabled) return;
    try {
      if (!this.audio)
        this.audio = new (window.AudioContext || window.webkitAudioContext)();
      this.audio.resume();
      const osc = this.audio.createOscillator(),
        gain = this.audio.createGain();
      osc.connect(gain);
      gain.connect(this.audio.destination);
      osc.type = kind === "emp" ? "sine" : "sawtooth";
      const now = this.audio.currentTime;
      osc.frequency.setValueAtTime(
        kind === "emp" ? 180 : kind === "hit" ? 120 : 420,
        now,
      );
      osc.frequency.exponentialRampToValueAtTime(30, now + 0.16);
      gain.gain.setValueAtTime(0.055, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc.start();
      osc.stop(now + 0.2);
    } catch {
      /* Audio is optional; simulation keeps running. */
    }
  }
  shoot(robot, point) {
    if (this.shotCooldown > 0) return false;
    this.shotCooldown = this.weaponMode === "missile" ? 1.1 : 0.17;
    const start = robot.muzzlePosition(),
      direction = point.clone().sub(start).normalize();
    if (this.weaponMode === "missile")
      this.addMissile(start, direction.multiplyScalar(32));
    else this.addBullet(start, direction.multiplyScalar(55), false);
    this.burst(start, 0xffbd6e, 3, 0.12);
    this.sound(this.weaponMode === "missile" ? "missile" : "shot");
    return true;
  }
  setWeapon(mode) {
    if (!["bullet", "missile"].includes(mode)) return;
    this.weaponMode = mode;
  }
  removeProjectile(projectile) {
    this.scene.remove(projectile.mesh);
    const materials = new Set();
    projectile.mesh.traverse((object) => {
      if (object.isMesh) materials.add(object.material);
    });
    for (const material of materials) material.dispose();
  }
  addMissile(position, velocity) {
    const mesh = new THREE.Group();
    const casing = new THREE.MeshStandardMaterial({
      color: 0xb9b39c,
      metalness: 0.65,
      roughness: 0.55,
    });
    const body = new THREE.Mesh(missileBodyGeo, casing);
    body.rotation.x = Math.PI / 2;
    mesh.add(body);
    const nose = new THREE.Mesh(missileNoseGeo, casing);
    nose.rotation.x = Math.PI / 2;
    nose.position.z = 0.925;
    mesh.add(nose);
    for (let i = 0; i < 4; i++) {
      const fin = new THREE.Mesh(boxGeo, casing);
      fin.position.set(
        Math.cos((i * Math.PI) / 2) * 0.16,
        Math.sin((i * Math.PI) / 2) * 0.16,
        -0.5,
      );
      fin.scale.set(0.45, 0.035, 0.38);
      fin.rotation.z = (i * Math.PI) / 2;
      mesh.add(fin);
    }
    const flame = new THREE.Mesh(
      sphereGeo,
      new THREE.MeshBasicMaterial({ color: 0xffbd68 }),
    );
    flame.position.z = -0.95;
    flame.scale.set(0.16, 0.16, 0.5);
    mesh.add(flame);
    mesh.position.copy(position);
    mesh.quaternion.setFromUnitVectors(
      new THREE.Vector3(0, 0, 1),
      velocity.clone().normalize(),
    );
    this.scene.add(mesh);
    this.bullets.push({
      mesh,
      velocity,
      life: 5,
      hostile: false,
      missile: true,
      flame,
      trailTime: 0,
      previous: position.clone(),
    });
    this.missilesFired++;
  }
  smoke(position) {
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(1, 6, 4),
      new THREE.MeshBasicMaterial({
        color: 0x9d9a87,
        transparent: true,
        opacity: 0.4,
        depthWrite: false,
      }),
    );
    mesh.position.copy(position);
    mesh.scale.setScalar(0.17);
    this.scene.add(mesh);
    this.effects.push({
      mesh,
      life: 0.65,
      max: 0.65,
      smoke: true,
      velocity: new THREE.Vector3(0, 0.5, 0),
    });
  }
  explode(position) {
    this.explosions++;
    this.destruction?.blast(position);
    this.burst(position, 0xffa453, 35, 0.85);
    const mesh = new THREE.Mesh(
      new THREE.SphereGeometry(1, 16, 10),
      new THREE.MeshBasicMaterial({
        color: 0xffca79,
        transparent: true,
        opacity: 0.75,
        depthWrite: false,
      }),
    );
    mesh.position.copy(position);
    this.scene.add(mesh);
    this.effects.push({ mesh, life: 0.5, max: 0.5, explosion: true });
    for (const enemy of this.enemies) {
      if (!this.enabled || enemy.dead) continue;
      const distance = enemy.root.position.distanceTo(position);
      if (distance > 7) continue;
      const cover = this.collision?.segmentHit(position, enemy.root.position);
      if (cover && cover.distance < distance - 0.15) continue;
      this.hit(enemy, distance < 3.5 ? 3 : 2);
    }
    this.sound("hit");
    this.onEvent("explosion");
  }
  addBullet(position, velocity, hostile) {
    const material = new THREE.MeshBasicMaterial({
      color: hostile ? 0xff7350 : 0xffd99a,
    });
    const mesh = new THREE.Mesh(sphereGeo, material);
    mesh.scale.set(0.075, 0.075, 0.55);
    mesh.position.copy(position);
    mesh.quaternion.setFromUnitVectors(
      new THREE.Vector3(0, 0, 1),
      velocity.clone().normalize(),
    );
    this.scene.add(mesh);
    this.bullets.push({
      mesh,
      velocity,
      life: 3,
      hostile,
      previous: position.clone(),
    });
  }
  burst(position, color, count = 10, duration = 0.55) {
    for (let i = 0; i < count; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color,
        transparent: true,
        opacity: 1,
      });
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.07, 0.3), mat);
      mesh.position.copy(position);
      mesh.rotation.set(rng() * 6, rng() * 6, rng() * 6);
      this.scene.add(mesh);
      this.effects.push({
        mesh,
        velocity: new THREE.Vector3(
          (rng() - 0.5) * 8,
          rng() * 6,
          (rng() - 0.5) * 8,
        ),
        life: duration,
        max: duration,
      });
    }
  }
  hit(enemy, damage = 1) {
    if (enemy.dead) return;
    enemy.health -= damage;
    this.burst(enemy.root.position, 0xffb565, 8);
    this.sound("hit");
    if (enemy.health <= 0) {
      enemy.dead = true;
      enemy.respawn = 8;
      enemy.root.visible = false;
      this.score++;
      this.burst(enemy.root.position, 0xffa659, 28, 0.85);
      this.onEvent("target");
    }
  }
  pulse(robot) {
    if (this.empCooldown > 0) return false;
    this.empCooldown = 5;
    const mesh = new THREE.Mesh(
      new THREE.RingGeometry(0.92, 1, 80),
      new THREE.MeshBasicMaterial({
        color: 0xc8e6c1,
        transparent: true,
        opacity: 0.8,
        side: THREE.DoubleSide,
        depthWrite: false,
      }),
    );
    mesh.rotation.x = -Math.PI / 2;
    mesh.position.copy(robot.position);
    mesh.position.y =
      robot.position.y + (robot.type === "wasp" ? robot.config.height : 0.09);
    this.scene.add(mesh);
    this.effects.push({ mesh, life: 0.8, max: 0.8, pulse: true });
    for (const enemy of this.enemies)
      if (
        this.enabled &&
        !enemy.dead &&
        enemy.root.position.distanceTo(robot.position) < 22
      )
        this.hit(enemy, 3);
    this.sound("emp");
    this.onEvent("emp");
    return true;
  }
  aim(ray, groundPoint) {
    let closest = Infinity,
      target = null;
    const hit = new THREE.Vector3();
    for (const e of this.enemies)
      if (this.enabled && !e.dead) {
        const point = ray.intersectSphere(
          new THREE.Sphere(e.root.position, 1.25),
          hit,
        );
        if (point) {
          const distance = point.distanceTo(ray.origin);
          if (
            distance < closest &&
            (!groundPoint || distance < groundPoint.distanceTo(ray.origin))
          ) {
            closest = distance;
            target = e.root.position.clone();
          }
        }
      }
    return target || groundPoint;
  }
  update(dt, time, robot, playing) {
    this.shotCooldown = Math.max(0, this.shotCooldown - dt);
    this.empCooldown = Math.max(0, this.empCooldown - dt);
    for (const e of this.enemies) {
      if (!this.enabled) continue;
      if (e.dead) {
        e.respawn -= dt;
        if (e.respawn <= 0) {
          e.dead = false;
          e.health = 3;
          e.root.visible = true;
          e.shootTime = 3;
        }
        continue;
      }
      const angle = e.angle + time * 0.025;
      const center = playing ? robot.position : this.center;
      const target = new THREE.Vector3(
        center.x + Math.sin(angle) * e.radius,
        center.y + e.baseHeight + Math.sin(time * 1.5 + e.angle) * 0.3,
        center.z + Math.cos(angle) * e.radius,
      );
      target.x = clamp(target.x, -115, 115);
      target.z = clamp(target.z, -115, 115);
      if (this.collision) {
        const motion = target.clone().sub(e.root.position).multiplyScalar(0.5);
        const result = this.collision.moveDrone(e.root.position, motion, dt, {
          height: 0,
          radius: 1.45,
        });
        e.root.position.copy(result.position);
      } else e.root.position.lerp(target, 1 - Math.exp(-dt * 0.5));
      e.root.lookAt(robot.position.x, e.root.position.y, robot.position.z);
      e.indicator.position.y =
        -e.root.position.y +
        (this.collision?.heightAt(
          e.root.position.x,
          e.root.position.z,
          e.root.position.y - 0.8,
        ) || 0) +
        0.035;
      for (const r of e.rotors) r.rotation.y += dt * 38;
      if (playing && robot.health > 0) {
        e.shootTime -= dt;
        if (e.shootTime <= 0) {
          e.shootTime = 3.5 + rng() * 3;
          const start = e.root.position.clone();
          const dir = robot.position
            .clone()
            .add(new THREE.Vector3(0, robot.config.height, 0))
            .sub(start)
            .normalize();
          this.addBullet(start, dir.multiplyScalar(15), true);
        }
      }
    }
    for (let i = this.bullets.length - 1; i >= 0; i--) {
      const b = this.bullets[i];
      b.previous.copy(b.mesh.position);
      b.mesh.position.addScaledVector(b.velocity, dt);
      b.life -= dt;
      if (b.missile) {
        b.flame.scale.z = 0.45 + Math.sin(time * 65) * 0.15;
        b.trailTime += dt;
        if (b.trailTime >= 0.04) {
          this.smoke(
            b.mesh.position
              .clone()
              .addScaledVector(b.velocity.clone().normalize(), -0.9),
          );
          b.trailTime %= 0.04;
        }
      }
      const travel = b.mesh.position.clone().sub(b.previous),
        distance = travel.length();
      const ray = new THREE.Ray(b.previous.clone(), travel.normalize());
      const terrainHit = this.collision?.segmentHit(
        b.previous,
        b.mesh.position,
      );
      let hitDistance = terrainHit?.distance ?? Infinity,
        hitEnemy = null,
        hitPlayer = false;
      if (!b.hostile) {
        for (const e of this.enemies)
          if (this.enabled && !e.dead) {
            const hit = ray.intersectSphere(
              new THREE.Sphere(e.root.position, 1.35),
              new THREE.Vector3(),
            );
            if (hit) {
              const d = hit.distanceTo(b.previous);
              if (d <= distance && d < hitDistance) {
                hitDistance = d;
                hitEnemy = e;
              }
            }
          }
      } else if (playing) {
        const body = robot.position
          .clone()
          .add(new THREE.Vector3(0, robot.config.height, 0));
        const hit = ray.intersectSphere(
          new THREE.Sphere(body, 1.65),
          new THREE.Vector3(),
        );
        if (
          hit &&
          hit.distanceTo(b.previous) <= distance &&
          hit.distanceTo(b.previous) < hitDistance
        )
          hitPlayer = true;
      }
      if (hitEnemy) {
        if (!b.missile) this.hit(hitEnemy);
        b.life = 0;
      } else if (hitPlayer) {
        robot.health = Math.max(0, robot.health - 5);
        this.burst(
          robot.position
            .clone()
            .add(new THREE.Vector3(0, robot.config.height, 0)),
          0xffa16a,
          5,
          0.25,
        );
        b.life = 0;
        this.onEvent("damage");
      } else if (terrainHit) {
        b.life = 0;
        this.terrainHits++;
        if (!b.missile && terrainHit.solid?.entity)
          this.destruction?.damage(terrainHit.solid.entity, 1, b.previous);
        this.burst(terrainHit.point, 0xccaf83, 4, 0.25);
      }
      if (b.life <= 0 || b.mesh.position.y < 0.05) {
        if (b.missile) {
          const impact = Number.isFinite(hitDistance)
            ? ray.at(Math.max(0, hitDistance - 0.06), new THREE.Vector3())
            : b.mesh.position.clone();
          this.explode(impact);
        }
        if (b.mesh.position.y < 0.05)
          this.burst(b.mesh.position, 0xccaf83, 3, 0.2);
        this.removeProjectile(b);
        this.bullets.splice(i, 1);
      }
    }
    for (let i = this.effects.length - 1; i >= 0; i--) {
      const e = this.effects[i];
      e.life -= dt;
      e.mesh.material.opacity =
        Math.max(0, e.life / e.max) * (e.smoke ? 0.4 : e.explosion ? 0.75 : 1);
      if (e.pulse) e.mesh.scale.setScalar(1 + (1 - e.life / e.max) * 22);
      else if (e.explosion)
        e.mesh.scale.setScalar(0.2 + (1 - e.life / e.max) * 5.5);
      else if (e.smoke) {
        e.mesh.scale.setScalar(0.17 + (1 - e.life / e.max) * 0.7);
        e.mesh.position.addScaledVector(e.velocity, dt);
      } else {
        e.velocity.y -= dt * 9;
        e.mesh.position.addScaledVector(e.velocity, dt);
      }
      if (e.life <= 0) {
        this.scene.remove(e.mesh);
        e.mesh.geometry.dispose();
        e.mesh.material.dispose();
        this.effects.splice(i, 1);
      }
    }
  }
}
